package com.my.library.helper;

import lombok.Data;

@Data
public class LoginHelper {
    private String email;
	private String password;
}
